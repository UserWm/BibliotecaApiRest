﻿using System.Net;

namespace apiCliente.DTOs
{
    public class RespuestaGenerica
    {
        public string Message { get; set; }
        public HttpStatusCode HttpCode { get; set; }
        public object Data { get; set; }

    }
}
