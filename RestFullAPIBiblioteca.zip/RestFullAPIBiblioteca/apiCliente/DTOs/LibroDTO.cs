﻿namespace apiCliente.DTOs
{
    public class LibroDTO
    {
        public int Id { get; set; }
        public string TituloLibro { get; set; }
        public int CantidadPaginas { get; set; }
        public string Editorial { get; set; }
        public int cantidad { get; set; }

    }
}
