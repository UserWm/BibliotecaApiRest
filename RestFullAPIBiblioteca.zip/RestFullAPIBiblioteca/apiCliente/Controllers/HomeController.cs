﻿using apiCliente.DTOs;
using apiCliente.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Text.Json;

namespace apiCliente.Controllers
{
    public class HomeController : Controller
    {
        private readonly IHttpClientFactory _httpClient;

        public HomeController(IHttpClientFactory httpClient)
        {
            _httpClient = httpClient;
        }

        JsonSerializerOptions options = new JsonSerializerOptions() { PropertyNameCaseInsensitive = true };

        // GET: EmployeesController
        public async Task<ActionResult> Index()
        {
            List<LibroDTO> libro = new List<LibroDTO>();
            try
            {
                var client = _httpClient.CreateClient("RestFullAPIBiblioteca");
                var response = await client.GetAsync("api/Libro");
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();

                    var result = JsonSerializer.Deserialize<RespuestaGenerica>(content, options);
                    if (result.HttpCode == System.Net.HttpStatusCode.OK)
                        libro = JsonSerializer.Deserialize<List<LibroDTO>>(result.Data.ToString(), options);


                    return View(libro);
                }
                return View();

            }
            catch
            {
                return View("Error");
            }
        }



    }
}